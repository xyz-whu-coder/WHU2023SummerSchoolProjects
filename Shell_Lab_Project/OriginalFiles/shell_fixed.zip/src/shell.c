#include "shell.h"

log_t Log;

/**
 * shell的入口
 */
void prefix() {

}

int execute(char* buffer) {

}
