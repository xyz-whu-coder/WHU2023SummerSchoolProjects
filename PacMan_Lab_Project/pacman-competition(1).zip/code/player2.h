#include "../include/playerbase.h"

struct Point walk(struct Player *player) {
	return initPoint(player->your_posx, player->your_posy);
}

void init(struct Player *player) {
}