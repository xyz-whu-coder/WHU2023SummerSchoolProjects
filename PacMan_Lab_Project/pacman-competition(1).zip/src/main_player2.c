/**
 * @file main_player.c
 * @author yangboyang@jisuanke.com
 * @copyright jisuanke.com
 * @date 2021-07-01
 */

#include <stdlib.h>
#include <assert.h>

#include "../code/player2.h"


int main(int argc, char *argv[]) {
    assert(argc >= 4);
    int playid = atoi(argv[3]);
    int read_fd, write_fd;
    read_fd = atoi(argv[1]);
    write_fd = atoi(argv[2]);
    struct Player player2;
    player2.mat = 0;
    _work(&player2, &read_fd, &write_fd, playid);
    return 0;
}
