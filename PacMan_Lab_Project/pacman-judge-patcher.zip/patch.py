from AwdPwnPatcher import *

binary = './judge'
patcher = AwdPwnPatcher(binary)

# vector size = 0x18
# 0x0   _M_start
# 0x8   _M_finish
# 0x10  _M_end_of_storage

# string size = 0x20
# 0x0   _M_dataplus         char*
# 0x8   _M_string_length    size_t
# 0x10  _anon_0             _M_local_buf[16] or size_t _M_allocated_capacity

# Game size = 0x130
# 0x0   data_path           string
# 0x20  player_path         string[2]
# 0x60  name                string[2]
# 0xA0  read_fd             int[2]
# 0xA8  write_fd            int[2]
# 0xB0  child_pid           int[2]
# 0xB8  row                 int
# 0xBC  column              int
# 0xC0  map                 vector<string>
# 0xD8  round               int
# 0xDC  init_ghost          POINT[2]
# 0xEC  ghost               POINT[2]
# 0xFC  pacman              POINT[2]
# 0x10C last_pacman         POINT[2]
# 0x11C score               int[2]
# 0x124 status              int[2]
# 0x12C align_gap           char[4]

# rdi   std::ostream&   std::cout
# rsi   char*           buffer 
# rdx   size_t          length
print_chars = patcher.add_patch_in_ehframe(
    assembly="""
    push rdi
    lea     rdi, [12080h]
    call    3730h
    pop rdi
    ret
    """
)

# rdi   std::ostream&   std::cout
# si    char            ch 
print_char = patcher.add_patch_in_ehframe(
    assembly="""
    push rdi
    lea     rdi, [12080h]
    call    34F0h
    pop rdi
    ret
    """
)

# rdi   std::ostream&   std::cout
flush_out = patcher.add_patch_in_ehframe(
    assembly="""
    push rdi
    lea     rdi, [12080h]
    call    3660h
    pop rdi
    ret
    """
)

# rdi   std::vector&    vector
# rsi   size_t          index
# return    rax std::string*
get_std_string_from_vector = patcher.add_patch_in_ehframe(
    assembly="""
    mov rax, [rdi]
    shl rsi, 5
    add rax, rsi
    ret
    """
)

# rdi   std::ostream&   std::cout
# rsi   std::string&    str
print_std_string = patcher.add_patch_in_ehframe(
    assembly=f"""
    push rdx
    mov rdx, [rsi + 8]
    mov rsi, [rsi]
    call {print_chars}
    pop rdx
    ret
    """
)

# r8d    number      int
# print_integer = patcher.add_patch_in_ehframe(
#     assembly=f"""
#     push rax
#     push rdi
#     push rsi
#     push rdx
#     push rcx
#     sub rsp, 20h
#     mov rdi, rsp
#     mov rsi, 1
#     mov rdx, 20h
#     lea rcx, [0E03Bh]   
#     call 3620h
#     mov rdi, rsp
#     call 35D0h
#     mov rdx, rax
#     mov rsi, rsp
#     call {print_chars}
#     add rsp, 20h
#     pop rcx
#     pop rdx
#     pop rsi
#     pop rdi
#     pop rax
#     ret
#     """
# )

# esi    number      int
print_integer = patcher.add_patch_in_ehframe(
    assembly=f"""
    push rdi
    lea  rdi, [12080h]
    call 3910h
    pop rdi
    ret
    """
)

# Game size = 0x130
# 0x0   data_path           string
# 0x20  player_path         string[2]
# 0x60  name                string[2]
# 0xA0  read_fd             int[2]
# 0xA8  write_fd            int[2]
# 0xB0  child_pid           int[2]
# 0xB8  row                 int
# 0xBC  column              int
# 0xC0  map                 vector<string>
# 0xD8  round               int
# 0xDC  init_ghost          POINT[2]
# 0xEC  ghost               POINT[2]
# 0xFC  pacman              POINT[2]
# 0x10C last_pacman         POINT[2]
# 0x11C score               int[2]
# 0x124 status              int[2]
# 0x12C align_gap           char[4]

# "On round" 0xE264

# rdi = Game* game
print_game_info = patcher.add_patch_in_ehframe(
    assembly=f"""
    push rcx
    push rbx
    push rdi
    push rsi
    push rdx
    push r8
    push rax
    
    mov rbx, rdi
    
    mov esi, [rbx + 0D8h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0B8h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0BCh]
    call {print_integer}
    mov rsi, 10
    call {print_char}

    mov esi, [rbx + 0DCh]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0E0h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0E4h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0E8h]
    call {print_integer}
    mov rsi, 10
    call {print_char}
    
    mov esi, [rbx + 0ECh]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0F0h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0F4h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0F8h]
    call {print_integer}
    mov rsi, 10
    call {print_char}
    
    mov esi, [rbx + 0FCh]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0100h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0104h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0108h]
    call {print_integer}
    mov rsi, 10
    call {print_char}
    
    mov esi, [rbx + 011Ch]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0120h]
    call {print_integer}
    mov rsi, 10
    call {print_char}
    
    mov esi, [rbx + 0124h]
    call {print_integer}
    mov rsi, 32
    call {print_char}
    
    mov esi, [rbx + 0128h]
    call {print_integer}
    mov rsi, 10
    call {print_char}
    
    xor r8d, r8d
    mov ecx, [rbx + 0B8h] 
    lea rdi, [rbx + 0C0h]
    
print_map_start:
    cmp r8d, ecx
    jge print_map_end
    
    push rdi
    push rcx
    push r8
    xor rsi, rsi
    mov esi, r8d
    call {get_std_string_from_vector}
    
    mov rsi, rax
    call {print_std_string}
    
    mov rsi, 10
    call {print_char}
    
    pop r8
    pop rcx
    pop rdi
    
    inc r8d
    jmp print_map_start
print_map_end:

    mov rsi, 10
    call {print_char}
    
    pop rax
    pop r8
    pop rdx
    pop rsi
    pop rdi
    pop rbx
    pop rcx
    ret
    """
)

# after game init
patcher.patch_by_jmp(
    0xC0D5, 0xC0DE,
    assembly=f"""
    mov rdi, rbx
    call {print_game_info}
    
    mov rdi, [rbx+20h]
    mov rsi, 1
    """
)

# after each round
patcher.patch_by_jmp(
    0xC168, 0xC16F,
    assembly=f"""
    push rdi
    mov rdi, rbx
    call {print_game_info}
    pop rdi
    
    mov r10d, [rbx+124h]
    """
)

# after game done
# patcher.patch_by_jmp(
#     0xC1FB, 0xC201,
#     assembly=f"""
#     push rdi
#     mov rdi, rbx
#     call {print_game_info}
#     pop rdi
# 
#     mov edi, [rbx+0A8h]
#     """
# )

patcher.save()
