#!/bin/bash

set -o pipefail
set -o errexit

WK_DIR=$(cd `dirname $0`; pwd)

player1="$WK_DIR/bin/player1"
player2="$WK_DIR/bin/player2"
log_dir="$WK_DIR/log/judge"

if [ ! -n "$1" ]; then
    exit -1
fi

map="$WK_DIR/data/$1"

cd $WK_DIR

ulimit -s 524288

if [ ! -d $WK_DIR/bin ]; then
    mkdir $WK_DIR/bin
fi

if [ ! -d $WK_DIR/log ]; then
    mkdir $WK_DIR/log
fi

if [ ! -d $WK_DIR/log/judge ]; then
    mkdir $WK_DIR/log/judge
fi

if [ ! -f $WK_DIR/code/player1.h ]; then
    exit -1
fi

if [ ! -f $WK_DIR/code/player2.h ]; then
    exit -1
fi

make -s check_player1 || exit -1
./bin/check_player1 "$map"
make -s check_player2 || exit -1
./bin/check_player2 "$map"
make -s player1 || exit -1
make -s player2 || exit -1
./bin/judge --data_file="$map" --player_red="$player1" --player_blue="$player2" --log_dir="$log_dir" || exit -1
