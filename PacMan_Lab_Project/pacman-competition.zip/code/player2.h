/**
 * @file player2.h
 * @author yangboyang@jisuanke.com
 * @copyright jisuanke.com
 * @date 2021-07-01
 */
#include <string.h>
#include "../include/playerbase.h"
#include <queue>
#include <cstdio>
#include <stdlib.h>
#include <time.h>
using namespace std;
int mapval[100][100];
void init(struct Player *player) {
    // This function will be executed at the begin of each game, only once.
}
int dir[5][2] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}, {0, 0}}, vis[100][100];
struct Point fa[100][100];
int walk_judge(struct Player *player, int nx, int ny) {
    if(nx < 0 || nx >= player->row_cnt || ny < 0 || ny >= player->col_cnt) return 0;
    if(player->mat[nx][ny] == '#') return 0;
    return 1;
}
int getDegree(struct Player *player, int x, int y) {
    int ret = 0;
    for(int i = 0; i < 4; i++) {
        int nx = x + dir[i][0], ny = y + dir[i][1];
        if(walk_judge(player, nx, ny)) ret++; 
    }
    return ret;
}
int judge(struct Player *player, int nx, int ny, int type) {
    switch(type) {
        case 0:
            return (player->mat[nx][ny] == 'o' ? 1 : 0);
        case 1:
            return (player->mat[nx][ny] == 'O' ? 1 : 0);
        case 2:
            return (nx == player->ghost_posx[0] && ny == player->ghost_posy[0]) || (nx == player->ghost_posx[1] && ny ==player->ghost_posy[1]);
        case 3:
            return (nx == player->opponent_posx && ny == player->opponent_posy);
    }
}
struct Point bfs(struct Player *player, int xx, int yy, int type) {
    // type: 0 for o, 1 for O, 2 for ghost, 3 for opponent
    // printff("next cube: %d %d\n", xx, yy); 
    // printff("finding: %d\n", type);
    memset(vis, 0, sizeof(vis));
    memset(fa, 0, sizeof(fa));
    queue<struct Point> q;
    while(!q.empty()) {q.pop();}
    struct Point tmp = {xx, yy};
    q.push(tmp);
    while(!q.empty()) {
        struct Point pos = q.front();
        q.pop();
        //// printff("my pos: %d %d\n", pos.X, pos.Y);
        if(judge(player, pos.X, pos.Y, type)) return pos;
        if(vis[pos.X][pos.Y]) continue;
        vis[pos.X][pos.Y] = 1;
        for(int i = 0; i < 4; i++) {
            int nx = pos.X + dir[i][0], ny = pos.Y + dir[i][1];
            //// printff("would go: %d %d\n", nx, ny);
            if(nx < 0 || nx >= player->row_cnt || ny < 0 || ny >= player->col_cnt) continue;
            if(player->mat[nx][ny] == '#') {
                continue;
            }
        struct Point ret = {nx, ny};
        //// printff("can go: %d %d\n", nx, ny);
        if(vis[nx][ny]) continue;
            fa[nx][ny] = pos;
            if(judge(player, nx, ny, type)) {
                // printff("found: %d, %d\n", ret.X, ret.Y);
                return ret;
            }
            q.push(ret);
        }
    }
    return {-1, -1};
}
struct Point find(struct Player *player, struct Point p) {
    // // printff("find: %d %d %d %d\n", p.X, p.Y,  player->your_posx, player->your_posy);
    if(p.X == -1 && p.Y == -1) return {player->your_posx, player->your_posy};
    if(fa[p.X][p.Y].X == player->your_posx && fa[p.X][p.Y].Y == player->your_posy) {
        return p;
    }
    return find(player, fa[p.X][p.Y]);
}
int getDistance(struct Player *player, int nx, int ny, struct Point p) {
    //// printff("find: %d %d %d %d\n", p.X, p.Y, nx, ny);
    if(p.X == -1 && p.Y == -1) return 100001; 
    if(nx == p.X && ny == p.Y) return 0;
    if(fa[p.X][p.Y].X == nx && fa[p.X][p.Y].Y == ny) {
        return 1;
    }
    return getDistance(player, nx, ny, fa[p.X][p.Y]) + 1;
}
int evaluationFunction(struct Player *player, int nx, int ny) {
    int value = 0;
    struct Point ret = bfs(player, nx, ny, 0); // nearest distance for food
    int distanceToFood = getDistance(player, nx, ny, ret);
    // printff("distanceToFood = %d\n", distanceToFood);
    ret = bfs(player, nx, ny, 1); // nearest distance for BIG food
    int distanceToBigFood = getDistance(player, nx, ny, ret);
    // printff("distanceToBigFood = %d\n", distanceToBigFood);
    ret = bfs(player, nx, ny, 2); // nearest distance for ghost
    int distanceToGhost = getDistance(player, nx, ny, ret);
    // printff("distanceToGhost = %d\n", distanceToGhost);
    ret = bfs(player, nx, ny, 3); // nearest distance for opponent
    int distanceToOpponent = getDistance(player, nx, ny, ret);
    // printff("distanceToOpponent = %d\n", distanceToOpponent);
    ret = bfs(player, player->opponent_posx, player->opponent_posy, 2);
    int OpponentToBigFood = getDistance(player, player->opponent_posx, player->opponent_posy, ret);
    // printff("OpponentToBigFood = %d\n", OpponentToBigFood);
    if(distanceToBigFood < 1) return 9999999;
    if(!player->your_status) {
        if(player->opponent_status) {
            distanceToGhost += distanceToOpponent;
        }
        if(distanceToOpponent <= 1 && player->opponent_status) {
            return -99999999;
        }
        if(distanceToGhost <= 1) {
            return -99999999 + distanceToGhost;
        }
        value -= (100 / (distanceToGhost * distanceToGhost));
        // printff("%d ??", value);
    }
    if(player->your_status) {
        if(!player->opponent_status) {
            // distanceToGhost += distanceToOpponent * 2;
        }
        value -= (distanceToGhost * player->your_status * player->your_status);
        if(distanceToGhost < 1 && player->your_status > 1) {
            return 99999999;
        }
        if(distanceToOpponent < 1 && (!player->opponent_status) && player->your_status > 1) {
            return 99999998;
        }
    }
    if(distanceToBigFood + 1 < OpponentToBigFood ) value += ((player->row_cnt * player->col_cnt) - distanceToBigFood) * 400;
    value += distanceToFood * -4 - 30 * distanceToBigFood;
    for(int i = 0; i < 5; i++) {
        int nxx = nx + dir[i][0], nyy = ny + dir[i][1];
        if(getDegree(player, nxx, nyy) <= 2) value -= 10;
    }
    return value;
}

struct Point walk(struct Player *player) {
    // This function will be executed in each round.
    // printff("\t\tmy position: %d %d\n", player->your_posx, player->your_posy);
    // printff("\t\tghost position: %d %d %d %d\n", player->ghost_posx[0], player->ghost_posy[0], player->ghost_posx[1],player->ghost_posy[1]);
    struct Point cur = {player->your_posx, player->your_posy};
    // priority_queue<pair<int, int>> q;
    // while(!q.empty()) q.pop();
    int maxm = -0x3f3f3f3f;
    struct Point action = cur;
    for(int i = 0; i < 5; i++) {
        int nx = cur.X + dir[i][0], ny = cur.Y + dir[i][1];
        if(!walk_judge(player, nx, ny)) continue;
        int val = evaluationFunction(player, nx, ny);
        // printff("Final Value: %d\n", val);
        if(maxm <= val) {
            if(maxm == val) {
                srand((unsigned)time(NULL));
                action = (rand() % 2) ? action : (struct Point){nx, ny};
            }
            else action = {nx, ny};
            maxm = val;
        }
    }
    return action;
}