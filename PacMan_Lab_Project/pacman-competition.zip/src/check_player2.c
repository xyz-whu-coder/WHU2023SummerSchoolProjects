/**
 * @file check_player2.cpp
 * @author zhengaohong@jisuanke.com
 * @copyright jisuanke.com
 * @version 0.0
 * @date 2016-08-01
 */

#include <assert.h>

#include "../code/player2.h"

int main(int argc, char **argv) {
    assert(argc > 1);
    struct Player player2;
    player2.mat = NULL;
    _syscall_check(&player2, argv[1]);
    return 0;
}
