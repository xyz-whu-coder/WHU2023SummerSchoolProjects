/**
 * @file check_player1.cpp
 * @author zhengaohong@jisuanke.com
 * @copyright jisuanke.com
 * @version 0.0
 * @date 2016-08-01
 */


#include <assert.h>

#include "../code/player1.h"

int main(int argc, char **argv) {
    assert(argc > 1);
    struct Player player1;
    player1.mat = NULL;
    _syscall_check(&player1, argv[1]);
    return 0;
}
