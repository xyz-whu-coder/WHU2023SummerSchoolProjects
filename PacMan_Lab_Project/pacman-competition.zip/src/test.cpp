#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

void test(const std::string& map_data, const std::string& output) 
{
    pid_t p1 = fork();
    if (p1 == 0) // child process
    {
        int fd = open(output.c_str(), O_RDWR | O_CLOEXEC | O_TRUNC | O_CREAT, S_IRWXU | S_IRWXG);
        if (fd < 0) 
        {
            perror("Failed to open output file ");
            exit(1);
        }
        dup2(fd, STDOUT_FILENO);
        execlp("./run.sh", "./run.sh", map_data.c_str(), nullptr);

        // These lines is not supposed to be executed
        perror("Execlp Failed: ");
        exit(1);
    } 
    else if (p1 > 0) // parent process
    {
        int status;
        pid_t w_result = waitpid(p1, &status, 0);
        if (WEXITSTATUS(status) != 0)
            return;
        else 
            return;
    }
    else 
    {
        perror("Failed to fork");
        exit(1);
    }
}

int main()
{
    std::string map_data = "map.txt";
    std::string output = "output";

    test(map_data, output);
    
    return 0;
}
